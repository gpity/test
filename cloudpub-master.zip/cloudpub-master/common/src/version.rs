pub const VERSION: &str = "1.1.54";
pub const BUILD: &str = "g073bcee";
pub const LONG_VERSION: &str = "1.1.54 build g073bcee";

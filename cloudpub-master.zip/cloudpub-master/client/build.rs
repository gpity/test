pub fn main() {
    /*    if std::env::var_os("CARGO_CFG_WINDOWS").is_some() {
            let mut res = winresource::WindowsResource::new();
            //res.set_manifest(include_str!("res/manifest.xml"));
            res.set_icon("res/icon.ico");
            res.compile().unwrap();
        }
    */
}
